from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import json,subprocess,shutil,os,urllib.request,time,webbrowser,threading
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True); FRONT=ROOT/'frontend'

def ollama(prompt,model='smollm2:1.7b-instruct-q4_K_S'):
    try:
        body=json.dumps({'model':model,'prompt':prompt,'stream':False,'options':{'temperature':.6,'num_ctx':2048}}).encode(); req=urllib.request.Request('http://127.0.0.1:11434/api/generate',body,{'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=90) as r:return json.loads(r.read())['response']
    except:return ''

def scenes(story,duration):
    n=max(4,min(30,round(duration/3)))
    p='''Turn this story into exactly %d short cartoon scene descriptions. Return one scene per line in this format: SCENE|title|visual description|narration. Keep each narration under 45 words. Story: %s'''%(n,story[:12000])
    raw=ollama(p); out=[]
    for line in raw.splitlines():
        if line.startswith('SCENE|'):
            x=line.split('|',3)
            if len(x)==4: out.append(x[1:])
    if not out:
        chunks=[x.strip() for x in story.replace('।','.').split('.') if x.strip()]
        for i in range(n):
            s=chunks[i%len(chunks)] if chunks else 'A happy village adventure begins.'
            out.append([f'Scene {i+1}',s,s])
    return out[:n]

def ppm(path,w,h,scene_no,title,desc):
    # Procedural cartoon frame: sky, ground, sun, two characters, props, title.
    pix=bytearray();
    for y in range(h):
      for x in range(w):
        if y<h*.62: c=(100+int(40*y/h),170+int(35*y/h),235)
        else: c=(95,175,90)
        pix.extend(c)
    def rect(x0,y0,x1,y1,c):
      for y in range(max(0,y0),min(h,y1)):
       a=(y*w+x0)*3;b=(y*w+x1)*3
       pix[a:b]=bytes(c)*(x1-x0)
    def circle(cx,cy,r,c):
      for y in range(max(0,cy-r),min(h,cy+r)):
       for x in range(max(0,cx-r),min(w,cx+r)):
        if (x-cx)**2+(y-cy)**2<=r*r: pix[(y*w+x)*3:(y*w+x+1)*3]=bytes(c)
    rect(0,int(h*.62),w,h,(75,150,75));circle(w-150,100,55,(255,220,70))
    for cx,shirt in [(int(w*.36),(50,90,220)),(int(w*.62),(220,70,90))]:
      circle(cx, int(h*.48),45,(245,190,145));rect(cx-38,int(h*.52),cx+38,int(h*.72),shirt);rect(cx-65,int(h*.72),cx-10,int(h*.77),(40,40,55));rect(cx+10,int(h*.72),cx+65,int(h*.77),(40,40,55));circle(cx-14,int(h*.47),5,(20,20,20));circle(cx+14,int(h*.47),5,(20,20,20))
    # simple kite
    pts=[(w//2,120),(w//2+35,155),(w//2,190),(w//2-35,155)]
    for i in range(4):
      x0,y0=pts[i];x1,y1=pts[(i+1)%4]
      # crude line
      import math
      steps=max(abs(x1-x0),abs(y1-y0))
      for k in range(steps+1):
       x=int(x0+(x1-x0)*k/max(1,steps));y=int(y0+(y1-y0)*k/max(1,steps));pix[(y*w+x)*3:(y*w+x+1)*3]=bytes((220,50,150))
    # PPM no text dependency; scene metadata encoded in filename/log.
    with open(path,'wb') as f:f.write(f'P6\n{w} {h}\n255\n'.encode());f.write(pix)

def tts(text,out):
    ps=shutil.which('powershell') or shutil.which('pwsh')
    if not ps:return False
    script=f'''Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SetOutputToWaveFile("{str(out).replace(chr(92),chr(92)*2)}"); $s.Speak("{text.replace(chr(34),chr(39)).replace(chr(13),' ').replace(chr(10),' ')}"); $s.Dispose()'''
    try:return subprocess.run([ps,'-NoProfile','-Command',script],timeout=60).returncode==0
    except:return False

def render(story,duration,language):
    ff=shutil.which('ffmpeg')
    if not ff:return 'FFmpeg not found. Install a Windows FFmpeg build and add its bin folder to PATH.',None
    ss=scenes(story,duration); work=OUT/'_render'; work.mkdir(exist_ok=True)
    logs=[]; per=max(1,duration*60/len(ss)); files=[]
    for i,(title,desc,narr) in enumerate(ss,1):
      img=work/f'{i:03}.ppm'; wav=work/f'{i:03}.wav'; ppm(img,1280,720,i,title,desc); tts(narr,wav); files.append((img,wav,per)); logs.append(f'Scene {i}/{len(ss)} created: {title}')
    # Build each scene clip, with zoom/pan and optional narration; concatenate.
    clips=[]
    for i,(img,wav,dur) in enumerate(files,1):
      clip=work/f'c{i:03}.mp4'; vf=f"zoompan=z='min(zoom+0.0008,1.12)':d={max(1,int(dur*25))}:s=1280x720:fps=25"; cmd=[ff,'-y','-loop','1','-i',str(img)]
      if wav.exists():cmd += ['-i',str(wav)]
      cmd += ['-vf',vf,'-t',str(dur),'-c:v','libx264','-pix_fmt','yuv420p']
      if wav.exists():cmd += ['-c:a','aac','-shortest']
      cmd += [str(clip)]; r=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
      if r.returncode!=0:return 'FFmpeg scene render failed: '+r.stderr.decode(errors='ignore')[-1200:],None
      clips.append(clip)
    lst=work/'concat.txt';lst.write_text(''.join("file '%s'\n"%str(x).replace("'","'\\''") for x in clips),encoding='utf8')
    out=OUT/f'cartoon_movie_{int(time.time())}.mp4'; r=subprocess.run([ff,'-y','-f','concat','-safe','0','-i',str(lst),'-c','copy',str(out)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    if r.returncode!=0:return 'Final merge failed: '+r.stderr.decode(errors='ignore')[-1200:],None
    return '\n'.join(logs)+f'\n\nDONE: {out.name}', '/output/'+out.name

class H(BaseHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/' or self.path=='/index.html':
   b=(FRONT/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(b);return
  if self.path.startswith('/output/'):
   p=OUT/self.path.split('/')[-1]
   if p.exists():
    b=p.read_bytes();self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
  self.send_error(404)
 def do_POST(self):
  if self.path!='/api/render':self.send_error(404);return
  n=int(self.headers.get('Content-Length','0'));d=json.loads(self.rfile.read(n));log,url=render(d['story'],int(d.get('duration',90)),d.get('language','Hindi'));b=json.dumps({'log':log,'url':url,'error':None if url else log}).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b)

if __name__=='__main__':
 s=ThreadingHTTPServer(('127.0.0.1',8765),H); threading.Timer(.8,lambda:webbrowser.open('http://127.0.0.1:8765')).start();print('Cartoon Film Studio: http://127.0.0.1:8765');s.serve_forever()

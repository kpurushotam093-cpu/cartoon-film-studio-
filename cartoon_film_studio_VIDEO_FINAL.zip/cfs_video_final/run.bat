@echo off
cd /d "%~dp0"
py -3.11 backend\server.py
if errorlevel 1 pause

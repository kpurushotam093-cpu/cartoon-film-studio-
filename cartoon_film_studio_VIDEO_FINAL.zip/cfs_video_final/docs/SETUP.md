1. Install Python 3.11.
2. Install FFmpeg and add its bin folder to PATH.
3. Optional: keep Ollama running with your local model.
4. Double-click run.bat.

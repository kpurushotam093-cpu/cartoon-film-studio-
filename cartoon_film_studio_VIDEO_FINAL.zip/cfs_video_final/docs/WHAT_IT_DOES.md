# What this build actually does
Story input -> scene breakdown -> cartoon frame per scene -> built-in Windows voice narration -> animated zoom/pan scene clips -> FFmpeg concatenation -> MP4.

The 2-minute and 5-minute options are for testing before attempting a long render. A 90-minute render can take a long time and produce a large file.

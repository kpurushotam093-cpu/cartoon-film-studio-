# Cartoon Film Studio — Video Build
This build creates an actual MP4 locally from a written story: scene plan, procedural cartoon frames, Windows built-in Speech synthesis, FFmpeg animation/encoding and final MP4 merge.

It is intentionally local/no API-key. Ollama is used when available for scene breakdown; otherwise a fallback splitter is used. Ollama's local Windows API runs at localhost:11434. The generated visuals are procedural cartoon frames, not neural text-to-video. High-end neural video generation is not bundled because it requires large models/GPU resources.

Run: double-click run.bat. The browser opens automatically.

Requirements: Windows 10/11, Python 3.11+, FFmpeg on PATH. Ollama is optional.
